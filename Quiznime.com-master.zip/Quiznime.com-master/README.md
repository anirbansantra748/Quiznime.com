# Quiznime.com

//SECTION - FILES
1. app.js
2. Views - pages -> index.ejs

//TODO - what to do
<--soumadeep-->
date - 28.10.23
1. make index route a suitable coppyright free background {using ai or find anywhere}
2. make a suitable nav bar and there have {home , quiz } in right of the nav bar make a logo of user and home also have the logo and quiz also
date - 29.10.23
3. make many divs in the index route like you visit this website to see -{https://www.beano.com/categories/quizzes}

